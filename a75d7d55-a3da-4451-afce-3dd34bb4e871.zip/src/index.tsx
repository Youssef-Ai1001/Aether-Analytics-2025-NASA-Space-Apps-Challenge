import React from 'react';
import './index.css';
import { render } from 'react-dom';
import { AppRouter } from './AppRouter';
render(<AppRouter />, document.getElementById('root'));